# Pupitar by Yzee4
#
# MIT License
#
# Copyright (c) 2023 Yzee4
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import os
import subprocess
import shutil
import sys
import re
import random

def colors():
    global white, cyan, lightred, lightgreen, yellow, lightblue, pink
    white = '\033[0;97m'
    cyan = '\033[0;36m'
    lightred = '\033[0;91m'
    lightgreen = '\033[0;92m'
    yellow = '\033[0;93m'
    lightblue = '\033[0;94m'
    pink = '\033[0;95m'

colors()

def verify_root():
    if os.geteuid() == 0:
        return True
    else:
        print(f"{lightred}[-] {white}Execute as root!")
        sys.exit()

verify_root()

def check_tool_installed(tool_name):
    if tool_name == 'net-tools':
        return os.path.exists('/sbin/ifconfig')
    else:
        return shutil.which(tool_name) is not None

def initializing_dottler():
    subprocess.call('clear')
    tools_to_check = ['arp-scan', 'nmap']
    not_installed_tools = []
    for tool in tools_to_check:
        if not check_tool_installed(tool):
            not_installed_tools.append(tool)
    if not_installed_tools:
        for tool in not_installed_tools:
            print(f"{lightred}[-] {yellow}{tool} {white}not installed. To install, use {lightgreen}'sudo apt install {tool}'{white}.")
        sys.exit()

initializing_dottler()

def scan_network():
    print(f"{yellow}[/] {white}Scanning may take a while, please wait a moment.")
    try:
        with open('/dev/null', 'w') as null_file:
            arp_scan_output = subprocess.check_output(['arp-scan', '--localnet'], universal_newlines=True, stderr=null_file)

        ip_addresses = []
        lines = arp_scan_output.split('\n')
        for line in lines:
            parts = line.split()
            if len(parts) >= 2:
                ip_address = parts[0]
                if re.match(r'\d+\.\d+\.\d+\.\d+', ip_address):
                    ip_addresses.append(ip_address)

        for ip_address in ip_addresses:
            try:
                nmap_output = subprocess.check_output(['nmap', '-F', ip_address], universal_newlines=True)
                print("")
                print(f"{lightgreen}IP: {white}{ip_address}")
                lines = nmap_output.split('\n')
                vulnerabilities = [] 
                for line in lines:
                    if "/tcp" in line:
                        parts = line.split()
                        port = parts[0]
                        state = parts[1]
                        service = parts[2]
                        vulnerabilities.append(f"{lightgreen}PORT: {white}{port} {lightgreen}STATE: {white}{state} {lightgreen}SERVICE: {white}{service}")
                        print(" ".join(vulnerabilities))
                        vulnerabilities = [] 

                if not any("/tcp" in line for line in lines):
                    vulnerabilities.append(f"{lightgreen}PORT: {yellow}None {lightgreen}STATE: {yellow}None {lightgreen}SERVICE: {yellow}None{white}")
                    print(" ".join(vulnerabilities))

            except subprocess.CalledProcessError as e:
                print(f"{lightred}[-] {white}Unknown error{white}.")
        print("")

    except subprocess.CalledProcessError as e:
        print(f"{lightred}[-] {white}Unknown error{white}.")
    except KeyboardInterrupt:
        print("")
        print(f"{lightgreen}[+] {white}Scan interrupted")
        print("")


def interface_variables():
    global color  
    global pupitar 

    def choose_color_randomly():
        color_codes = {
        'yellow': '\033[0;93m',
        'lightblue': '\033[0;94m',
        'lightred': '\033[0;91m',
        'cyan': '\033[0;96m',
        'pink': '\033[0;95m',
        }

        pupitar_values = {
        'yellow': '\033[7;3;93m',
        'lightblue': '\033[7;3;94m',
        'lightred': '\033[7;3;91m',
        'cyan': '\033[7;3;96m',
        'pink': '\033[7;3;95m',
        }
        randomcolor_name = random.choice(list(color_codes.keys()))
        color = color_codes[randomcolor_name]
        pupitar = pupitar_values.get(randomcolor_name, 'unknown')
        return color, pupitar

    color, pupitar = choose_color_randomly()

    def interface_arguments():
        global head
        global randominterface
        global interface

        head = (f"""{white}What do you know?""")
        interfaces_codes = {
        "Interface 1":"""
██████╗ ██╗   ██╗██████╗ ██╗████████╗ █████╗ ██████╗ 
██╔══██╗██║   ██║██╔══██╗██║╚══██╔══╝██╔══██╗██╔══██╗
██████╔╝██║   ██║██████╔╝██║   ██║   ███████║██████╔╝
██╔═══╝ ██║   ██║██╔═══╝ ██║   ██║   ██╔══██║██╔══██╗
██║     ╚██████╔╝██║     ██║   ██║   ██║  ██║██║  ██║
╚═╝      ╚═════╝ ╚═╝     ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝""",}
                                            
        interfaces = list(interfaces_codes.keys())
        randominterface_name = random.choice(interfaces)
        randominterface = interfaces_codes[randominterface_name]

        interface = (f"""{white}Make sure you are using the latest version at {lightgreen}'https://github/com/yzee4/Pupitar'{white}.  
                                                  
{color}   <\> {white}Coded by Yzee4
{color}   <\> {white}Produced on Python

{white}To start scan, use {lightgreen}'scan'{white}.
""")
    interface_arguments()

interface_variables()

def show_interface():
    reset_color = '\033[0m'
    subprocess.call('clear')
    print(f'''{color}{head}{color}{randominterface}\n{interface}{reset_color}''')

show_interface()

def main():
    try:
        while True:
            dconsole = input(f"{pupitar}pupitar{white} > ").strip()

            if dconsole == "scan":
                scan_network()

            elif dconsole == "clear":
                subprocess.run("clear")
                show_interface()
                main()

            else:
                print(f"{lightred}[-] {white}Unknown command: {dconsole}.")
                print('')

    except KeyboardInterrupt:
        print('')
        print(f'{yellow}[/] {white}Thank for using! :)')
        sys.exit()
main()